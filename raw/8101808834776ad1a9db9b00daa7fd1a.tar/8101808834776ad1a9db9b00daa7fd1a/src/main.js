import css from './css.styl'

export default function main() {
    const node = document.querySelector('#root')
    node.classList.add(css.container)

    node.innerHTML = '#'
}
