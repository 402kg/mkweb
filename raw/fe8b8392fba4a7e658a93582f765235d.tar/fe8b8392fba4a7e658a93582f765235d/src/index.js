import '@babel/polyfill'

import main from './main'

if (module.hot) {
    module.hot.accept('./main.js', () => {
        main()
    })
}

main()
