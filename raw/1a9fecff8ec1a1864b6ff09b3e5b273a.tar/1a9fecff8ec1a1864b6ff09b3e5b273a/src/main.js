import css from './css.scss'

export default function main() {
    const node = document.querySelector('#root')
    node.classList.add(css.container)

    node.innerHTML = '#'
}
