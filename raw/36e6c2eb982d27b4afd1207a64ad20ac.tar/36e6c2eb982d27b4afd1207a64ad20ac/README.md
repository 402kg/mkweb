# {name}

### Fetures
- Babel 7
- Webpack + HMR
- Stylus preprocessor

### Runnng
`yarn start` will expose app at `:8000` port

### Production build
`NODE_ENV=production` yarn dist

