# {name}

### Fetures
- Babel 7
- Webpack + HMR
- React 16.*
- SASS preprocessor

### Runnng
`yarn start` will expose app at `:8000` port

### Production build
`NODE_ENV=production` yarn dist
